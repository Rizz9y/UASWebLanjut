import React from 'react';

function Dashboard() {
  return (
    <div>
      <h2>Dashboard Admin</h2>
      <p>Selamat datang di panel admin. Di sini Anda bisa mengelola semua data gudang.</p>
    </div>
  );
}

export default Dashboard;
